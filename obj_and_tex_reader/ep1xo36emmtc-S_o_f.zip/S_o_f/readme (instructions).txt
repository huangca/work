Thank you for downloading the UNSC Halo Wars Spirit of Fire Model.

This model was made for personal use only. No exceptions. This Halo UNSC Spirit of Fire model may not be used in any profited organizations. This includes games, short films, movies etc. If you wish to do so, please contact me and I would be happy to arrange terms to do so. IF THIS MODEL IS USED FOR A NON-PROFIT ORGANIZATION, CREDIT MUST BE GIVEN TO THE PROPER NAME/PERSON (the designer of this model is “Luca Scarci”) 

I hope you enjoy the UNSC Spirit of Fire 3D Model.

	-Luca Scarci 